import os
import tempfile
import json
from eralchemy2 import render_er

def lambda_handler(event, context):
    try:
        # Configuramos el PATH para que Lambda encuentre Graphviz
        os.environ['PATH'] += os.pathsep + '/usr/bin'
        
        # Parseamos el input (ejemplo)
        body = json.loads(event.get('body', '{}'))
        schema_definition = body.get('schema', '')

        # Generamos el diagrama ER en un archivo temporal
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
            output_path = tmp_file.name
        
        render_er(schema_definition, output_path)
        
        # Leemos la imagen y la devolvemos
        with open(output_path, 'rb') as f:
            image_data = f.read()
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'image/png',
                'Access-Control-Allow-Origin': '*'
            },
            'body': image_data.hex(),  # Convertimos a hexadecimal para Lambda
            'isBase64Encoded': True
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
